class appIntro {

    startIntro(introSlides) {
        this.injectIntroWidgBackdrop();
        this.addFirstIntroSlide(introSlides[0]);
        this.introControls(this, introSlides);
    }

    injectIntroWidgBackdrop() {
        $("body").append(` <div class="intro-main-wrapper wrapper"></div> `);
    }

    addFirstIntroSlide(slides) {
        $(".intro-main-wrapper").html(this.slideWidget({
            slide_num:   0,
            bg_image:    slides['bg_image'],
            title:       slides['title'],
            description: slides['description']
        }));
    }

    introControls(self, introSlides) {
        // go forward
        $("body").on('click', '.intro-wrapper-next', function() {
            const nextBtn              =  $(this);
            let slideSelf              =  nextBtn.parents("#intro_wrapper");
            let currentIntroPosition   =  parseInt(slideSelf.attr('slide-number'));
            let increment = currentIntroPosition +=1;


            // intro has ended
            if (currentIntroPosition == ( introSlides.length )) {
                slideSelf.find(".intro-wrapper-prev").hide('slow', function() {
                    $(".intro-wrapper-next").attr("end-intro", "true").html(`Done <i class="fa fa-arrow-right"></i>`);
                });
            } 
            // instro now has history
            else if (increment > 0) {
                $(".intro-main-wrapper").html(self.slideWidget({
                    slide_num:   increment,
                    bg_image:    introSlides[increment]['bg_image'],
                    title:       introSlides[increment]['title'],
                    description: introSlides[increment]['description']
                }));
                $(".intro-main-wrapper").find(".intro-wrapper-prev").show(0);
            } else {
                $(".intro-main-wrapper").html(self.slideWidget({
                    slide_num:   increment,
                    bg_image:    introSlides[increment]['bg_image'],
                    title:       introSlides[increment]['title'],
                    description: introSlides[increment]['description']
                }));
            }
        });

        // end intro
        $("body").on("click", "[end-intro='true']", function() {
            $(".intro-main-wrapper").fadeOut('slow', function() {
                $(this).remove();
            });
        });


         // go backward
         $("body").on("click", '.intro-wrapper-prev', function () {
            const prevBtn              =  $(this);
            let slideSelf              =  prevBtn.parents("#intro_wrapper");
            let currentIntroPosition   =  parseInt(slideSelf.attr('slide-number'));
            let decrement = currentIntroPosition -=1;
            
            if ($(this).find(this)) {
                    if (currentIntroPosition != 0) {
                        $(".intro-main-wrapper").html(self.slideWidget({
                            slide_num:   decrement,
                            bg_image:    introSlides[decrement]['bg_image'],
                            title:       introSlides[decrement]['title'],
                            description: introSlides[decrement]['description']
                        }));
                    $(".intro-main-wrapper").find(".intro-wrapper-prev").show(0);   

                    console.log(currentIntroPosition);
                } else if (currentIntroPosition == 0){
                    $(".intro-main-wrapper").html(self.slideWidget({
                        slide_num:   decrement,
                        bg_image:    introSlides[decrement]['bg_image'],
                        title:       introSlides[decrement]['title'],
                        description: introSlides[decrement]['description']
                    }));
                }
            }
            
        })
        
    }

    slideWidget(options) {
        return `
            <div id="intro_wrapper" class="intro-wrapper  text-white" slide-number="${options.slide_num}">
                <div class="image_wrapper d-flex row text-danger ">
                    <div class="image-div" style="background-image: url(${options.bg_image})">
                    </div>
                </div>
                <div class="intro-div intro-div--slanted d-flex flex-column">
                    <div class="intro-div-content d-flex flex-column">
                        <h1 class="title">${options.title}</h1>
                        <p class="description">${options.description}</p>
                        <div class="row">
                            <div class="col-6 d-flex justify-content-start">
                                <span class="intro-wrapper-prev btn btn-outline-primary text-white" style="display: none;">
                                    <i class="fa fa-arrow-left"></i> Prev
                                </span>
                            </div>
                            <div class="col-6 d-flex justify-content-end">
                                <span class="intro-wrapper-next btn btn-outline-success text-white" id="Next">
                                    Next <i class="fa fa-arrow-right"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

}

let intro = new appIntro();
 
intro.startIntro([
    {title:"Hello", description:"Doe", bg_image: "image.svg"},
    {title:"Easy Course Planning", description:"Doe", bg_image: "image.svg"},
    {title:"Website Management", description:"Doe", bg_image: "image.svg"},
    {title:"Free Electronic bulletin", description:"Doe", bg_image: "image.svg"},
    {title:"Online enrollment", description:"Doe", bg_image: "image.svg"},
]);




// showfirstIntro();
    

